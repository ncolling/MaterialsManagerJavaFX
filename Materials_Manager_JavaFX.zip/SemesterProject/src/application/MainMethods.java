/**
 * Raid Materials Generator
 * Nicholas Colling
 * A program that takes input from the user for properties of their raid, including: raid size, raid nights, boss pulls,
 * and raid composition and prints a material list for making all necessary consumables for that week of raiding.
 */
package application;

public class MainMethods 
{
	public static void MainMethod(Integer[] getData)
	{
		
		//Calls the method for user input and returns specifications for raid
		Integer[] userInput = getData; 
		
		/**
		 * Creates all class objects to be used to gain personal consumables
		 * such as potion type and weapon augment type
		 */
			Heals heals = new Heals(0, 0, 1); 

			Dps caster = new Dps(1, 1, 1, 1); 
		
			Dps rangedAgi = new Dps(2, 1, 1, 1); 
			
			Dps meleeAgi = new Dps(2, 2, 2, 1);  
			
			Dps melee1HStr = new Dps(3, 3, 1, 1); 
			
			Dps melee2HStr = new Dps(3, 3, 2, 1);
			
			Tank strTank = new Tank(3, 3, 1, 1); 
			
			Tank agiTank = new Tank(2, 2, 2, 1);
		
		//Generates an array that stores the count of how many of each type of potion
		Integer[] flaskCounts = flaskCounts(userInput, heals.getPotionType(), caster.getPotionType(), rangedAgi.getPotionType(),
				meleeAgi.getPotionType(), melee1HStr.getPotionType(), melee2HStr.getPotionType(),
				strTank.getPotionType(), agiTank.getPotionType());
		
		//Generates an array that stores the count of how many of each type of weapon augment
		Integer[] weaponAugmentCounts = weaponAugmentCounts(userInput, heals.getWeaponAugmentType(), caster.getWeaponAugmentType(), 
				rangedAgi.getWeaponAugmentType(), meleeAgi.getWeaponAugmentType(), meleeAgi.getWeaponCount(), melee1HStr.getWeaponAugmentType(),
				melee2HStr.getWeaponAugmentType(), melee2HStr.getWeaponCount(), strTank.getWeaponAugmentType(), agiTank.getWeaponAugmentType(),
				agiTank.getWeaponCount());
		
		//Generates an array that combines all counts from previous arrays for material list
		Integer[] consumablesCounts = consumablesCounts(userInput, flaskCounts, weaponAugmentCounts);
		
		
		//prints the required materials for the week of raid from user input
		toOutput(consumablesCounts);
	}	
	
	public static Integer[] houseKeeping()
	{
		Integer[] userInput = new Integer[11];
		
		
		
		return userInput;
	}
	
	public static Integer[] flaskCounts(Integer[] userInput, int heals, int casters, int rangedAgis, int meleeAgis, int melee1HStrs,
			int melee2HStrs, int strTanks, int agiTanks)
	{
		//Variable declarations and initializations
		Integer[] flaskCounts = new Integer[2];
		int heal = readFlask(heals);
		int caster = readFlask(casters);
		int rangedAgi = readFlask(rangedAgis);
		int meleeAgi = readFlask(meleeAgis);
		int agiTank = readFlask(agiTanks);
		int melee1HStr = readFlask(melee1HStrs);
		int melee2HStr = readFlask(melee2HStrs);
		int strTank = readFlask(strTanks);
		
		//Array assignment with the counts of each type of flask
		flaskCounts[0] = 2*userInput[1] * (heal * userInput[2] + rangedAgi * userInput[4] + caster * userInput[3]); //Elemental Chaos
		flaskCounts[1] = 2*userInput[1] * (meleeAgi * userInput[5] + agiTank * userInput[9] + 
				melee1HStr * userInput[6] + melee2HStr * userInput[7] + strTank * userInput[8]); //Glacial Fury
		
		
		return flaskCounts;
	}
	
	public static Integer[] weaponAugmentCounts(Integer[] userInput, int heals, int casters, int rangedAgis, int meleeAgis, int agiWeaponCount,
			int melee1HStrs, int melee2HStrs, int strWeaponCount, int strTanks, int agiTanks, int agiTankWeaponCount)
	{
		//Variable declarations and initializations
		Integer[] weaponAugmentCounts = new Integer[3];
		int heal = readWeapon(heals);
		int caster = readWeapon(casters);
		int rangedAgi = readWeapon(rangedAgis);
		int meleeAgi = readWeapon(meleeAgis);
		int melee1HStr = readWeapon(melee1HStrs);
		int melee2HStr = readWeapon(melee2HStrs);
		int strTank = readWeapon(strTanks);
		int agiTank = readWeapon(agiTanks);
		
		//Array assignment with the counts of each type of weapon augment
		weaponAugmentCounts[0] = userInput[1] * (caster * userInput[3] + heal * userInput[2]); //Howling Rune
		weaponAugmentCounts[1] = userInput[1] * (rangedAgi * userInput[4]); //Completely Safe Rockets
		weaponAugmentCounts[2] = userInput[1] * (meleeAgi * userInput[5] * agiWeaponCount + agiTank * userInput[9] * agiWeaponCount+
				melee1HStr * userInput[6] + melee2HStr * userInput[7] * strWeaponCount + 
				strTank * userInput[8]); //Buzzing Rune
		
		return weaponAugmentCounts;
	}
	
	//A method to take the flask type and say if it exists
	public static int readFlask(int flaskType)
	{
		int flask = 0;
		if (flaskType >= 0)
			flask = 1;
		
		return flask;
	}
	
	//A method to take the augment type and say if it exists
	public static int readWeapon(int augmentType)
	{
		int weaponAugmentType = 0;
		if (augmentType >= 0)
			weaponAugmentType = 1;
		
		return weaponAugmentType;
	}
	
	//Method for generating number of cauldrons needed
	public static int getCauldron(int raidHours)
	{
		int cauldronCount = 1;
		if (raidHours > 2)
			cauldronCount = 2;
		if (raidHours > 5)
			cauldronCount = 3;
		
		return cauldronCount;
	}
	
	//Method for generating number of feasts needed
	public static int getFeasts(int raidHours)
	{
		int pullCounts = 10;
		int feasts = pullCounts * raidHours;
		
		return feasts;
	}
	
	//Method to build the array for Consumables Counts
	public static Integer[] consumablesCounts(Integer[] userInput, Integer[] potionCounts, Integer[] weaponAugmentCounts)
	{
		//variable declarations and initializations
		Integer[] consumablesCounts = new Integer[7];
		consumablesCounts[0] = getCauldron(userInput[1]); // 0
		consumablesCounts[1] = getFeasts(userInput[1]); // 1
		
		//for loops assign consumablesCounts array from potionCounts and weaponAugmentCounts 
		for (int i = 2, j = 0; j < 2; i++, j++)
		{
			consumablesCounts[i] = potionCounts[j]; //2 - 3
		}
		
		for (int i = 4, j = 0; j < 3; i++, j++ ) // 4 - 6
		{
			consumablesCounts[i] = weaponAugmentCounts[j];
		}
		/**
		 * Consumables List Index:
		 * 0 - # of Cauldrons
		 * 1 - # of Feasts
		 * 2 - Elemental Chaos
		 * 3 - Glacial Fury
		 * 4 - Howling Rune
		 * 5 - Completely Safe Rockets
		 * 6 - Buzzing Rune
		 */
		
		return consumablesCounts;
	}
	

	
	//method to display output of needed materials for weekly raid
	public static void toOutput(Integer[] consumablesCounts)
	{
		
		SemesterProjectGUI.tfCauldronOfPower.setText(consumablesCounts[0].toString());
		SemesterProjectGUI.tfFeasts.setText(consumablesCounts[1].toString());
		SemesterProjectGUI.tfElementalChaos.setText(consumablesCounts[2].toString());
		SemesterProjectGUI.tfGlacialFury.setText(consumablesCounts[3].toString());
		SemesterProjectGUI.tfHowlingRune.setText(consumablesCounts[4].toString());
		SemesterProjectGUI.tfRockets.setText(consumablesCounts[5].toString());
		SemesterProjectGUI.tfBuzzingRune.setText(consumablesCounts[6].toString());
		
	}
}
