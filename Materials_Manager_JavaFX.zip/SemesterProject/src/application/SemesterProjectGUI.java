/**
 * Raid Materials Generator Updated for Dragonflight
 * Nicholas Colling
 * A class for the GUI application of the Raid Materials Generator using JavaFX.
 * Requires MainMethods, CharacterClass, Dps, Heals, and Tank classes for functionality.
 */

package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SemesterProjectGUI extends Application
{
	//Textfield generations, static fields are used within MainMethods class
	private TextField tfRaidHours = new TextField();
	private TextField tfBossPulls = new TextField();
	private TextField tfHealers = new TextField();
	private TextField tfCasterDps = new TextField();
	private TextField tfRangedDps = new TextField();
	private TextField tfMeleeAgiDps = new TextField();
	private TextField tf1HStrDps = new TextField();
	private TextField tf2HStrDps = new TextField();
	private TextField tfStrTank = new TextField();
	private TextField tfAgiTank = new TextField();
	protected static TextField tfCauldronOfPower = new TextField();
	protected static TextField tfFeasts = new TextField();
	protected static TextField tfElementalChaos = new TextField();
	protected static TextField tfGlacialFury = new TextField();
	protected static TextField tfHowlingRune = new TextField();
	protected static TextField tfRockets = new TextField();
	protected static TextField tfBuzzingRune = new TextField();
	
	
	@Override
	public void start(Stage primaryStage)
	{
		//Sets the label text of the GUI
		Label title = new Label();
			title.setText("Welcome to the Raid Materials Generator.\n"+
				"Fill out the following forms and select Generate Mats.");
		
		//GridPane is used to set the formatted placements of all the textfields
		GridPane mainPane = new GridPane();
		mainPane.setHgap(5);
		mainPane.setVgap(5);
		mainPane.add(new Label("Enter number of Hours of Raid:"), 0, 0);
		mainPane.add(tfRaidHours, 1, 0);
		mainPane.add(new Label("Enter number of Healers:"), 0, 1);
		mainPane.add(tfHealers, 1, 1);
		mainPane.add(new Label("Enter number of Caster DPS:"), 0, 2);
		mainPane.add(tfCasterDps, 1, 2);
		mainPane.add(new Label("Enter number of Ranged DPS:"), 0, 3);
		mainPane.add(tfRangedDps, 1, 3);
		mainPane.add(new Label("Enter number of Melee Agi DPS:"), 0, 4);
		mainPane.add(tfMeleeAgiDps, 1, 4);
		mainPane.add(new Label("Enter number of 1H Str DPS:"), 0, 5);
		mainPane.add(tf1HStrDps, 1, 5);
		mainPane.add(new Label("Enter number of 2H Str DPS:"), 0, 6);
		mainPane.add(tf2HStrDps, 1, 6);
		mainPane.add(new Label("Enter number of Str Tanks:"), 0, 7);
		mainPane.add(tfStrTank, 1, 7);
		mainPane.add(new Label("Enter number of Agi Tanks:"), 0, 8);
		mainPane.add(tfAgiTank, 1, 8);
		
		//Variable declaration and initialization of starting condition
		final String DEFAULT = "0";
		tfRaidHours.setText(DEFAULT);
		tfBossPulls.setText(DEFAULT);
		tfHealers.setText(DEFAULT);
		tfCasterDps.setText(DEFAULT);
		tfRangedDps.setText(DEFAULT);
		tfMeleeAgiDps.setText(DEFAULT);
		tf1HStrDps.setText(DEFAULT);
		tf2HStrDps.setText(DEFAULT);
		tfStrTank.setText(DEFAULT);
		tfAgiTank.setText(DEFAULT);
		
		//Assigns the placement of the return textfields and whether editable
		mainPane.add(new Label("Potion Cauldron of Ultimate Power:"), 2, 0);
		mainPane.add(tfCauldronOfPower, 3, 0);
		tfCauldronOfPower.setEditable(false);
		mainPane.add(new Label("Feasts:"), 2, 1);
		mainPane.add(tfFeasts, 3, 1);
		tfFeasts.setEditable(false);
		mainPane.add(new Label("Phial of Elemental Chaos:"), 2, 2);
		mainPane.add(tfElementalChaos, 3, 2);
		tfElementalChaos.setEditable(false);
		mainPane.add(new Label("Phial of Glacial Fury:"), 2, 3);
		mainPane.add(tfGlacialFury, 3, 3);
		tfGlacialFury.setEditable(false);
		mainPane.add(new Label("Howling Rune:"), 2, 4);
		mainPane.add(tfHowlingRune, 3, 4);
		tfHowlingRune.setEditable(false);
		mainPane.add(new Label("Completely Safe Rockets:"), 2, 5);
		mainPane.add(tfRockets, 3, 5);
		tfRockets.setEditable(false);
		mainPane.add(new Label("Buzzing Rune:"), 2, 6);
		mainPane.add(tfBuzzingRune, 3, 6);
		tfBuzzingRune.setEditable(false);
		
		
		//Creates the buttons for calling MainMethods and Reset
		Button btGenerateMats = new Button("Generate Mats");
		Button btReset = new Button("Reset");
		
		
		mainPane.add(btGenerateMats, 1, 13);
		mainPane.add(btReset, 2, 13);
		
		//Creates border pane for formatting node positioning
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(10,20,10,20));
		pane.setTop(title);
		pane.setCenter(mainPane);
		

		//Creates on click action for buttons
		btGenerateMats.setOnAction(e -> start());
		btReset.setOnAction(e -> reset());

		//Creates the Scene and places stage
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Raid Materials Generator"); 
		primaryStage.setScene(scene); 
		primaryStage.show(); 
		
	}
	
	
	private void start()
	{
		//Variable Array declaration for holding inputs from user
		Integer[] userInput = new Integer[11];
		
		try 
		{
			userInput[0] = 0;
			userInput[1] = Integer.parseInt(tfRaidHours.getText());
			userInput[2] = Integer.parseInt(tfHealers.getText());
			userInput[3] = Integer.parseInt(tfCasterDps.getText());
			userInput[4] = Integer.parseInt(tfRangedDps.getText());
			userInput[5] = Integer.parseInt(tfMeleeAgiDps.getText());
			userInput[6] = Integer.parseInt(tf1HStrDps.getText());
			userInput[7] = Integer.parseInt(tf2HStrDps.getText());
			userInput[8] = Integer.parseInt(tfStrTank.getText());
			userInput[9] = Integer.parseInt(tfAgiTank.getText());
			
			//Calls MainMethods class to run the necessary computations
			MainMethods.MainMethod(userInput);
		}
		
		//Catches parseInt errors and triggers sendAlert method
		catch (NumberFormatException ex)
		{
			sendAlert();
		}
	}
	
	//Method for sending error alert to user for invalid inputs
	public void sendAlert()
	{
	 
		Alert alert = new Alert(AlertType.INFORMATION);
	    alert.setTitle("Error!");
	    alert.setHeaderText("An error occurred.");
	    String s = "Please enter only integer numbers.";
	    alert.setContentText(s);
	    alert.show();
	}
	
	//Method for resetting the GUI to default parameters
	public void reset()
	{
		//variable declaration and initialization
		final String RESET = "0";
		final String RESET2 = " ";
		
		//Field entry modifications
		//input
		tfRaidHours.setText(RESET);
		tfHealers.setText(RESET);
		tfCasterDps.setText(RESET);
		tfRangedDps.setText(RESET);
		tfMeleeAgiDps.setText(RESET);
		tf1HStrDps.setText(RESET);
		tf2HStrDps.setText(RESET);
		tfStrTank.setText(RESET);
		tfAgiTank.setText(RESET);
		
		//output
		tfCauldronOfPower.setText(RESET2);
		tfFeasts.setText(RESET2);
		tfElementalChaos.setText(RESET2);
		tfGlacialFury.setText(RESET2);
		tfHowlingRune.setText(RESET2);
		tfRockets.setText(RESET2);
		tfBuzzingRune.setText(RESET2);
	}
	
	//main method to launch primary stage
	public static void main(String[] args)
	{
		launch(args);
	}
}
